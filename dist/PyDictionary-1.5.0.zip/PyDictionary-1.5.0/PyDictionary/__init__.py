__author__ = "Pradipta Bora"
__version__ = "1.5.0"

try:
    from .core import *
except:
    from core import *

